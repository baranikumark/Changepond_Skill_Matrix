package com.changepond.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.changepond.model.ContactUs;
import com.changepond.serviceImpl.ContactUsServiceImplementation;

@WebServlet("/ContactUsController")
public class ContactUsController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try {
			
			String name=request.getParameter("name");
			String email=request.getParameter("email");
			String subject=request.getParameter("subject");
			String message=request.getParameter("message");
			
			ContactUs conus=new ContactUs();
			
			conus.setName(name);
			conus.setEmail(email);
			conus.setSubject(subject);
			conus.setMessage(message);
			
		
			
			ContactUsServiceImplementation obj=new ContactUsServiceImplementation();
			int checkFlag=obj.save(conus);
			if(checkFlag!=0){
				 pw.println("<script type=\"text/javascript\">");
				 pw.println("alert('Succesfull');");
				 pw.println("</script>");
			
			}
			else
			{
				pw.println("<script type=\"text/javascript\">");
				 pw.println("alert('Try Again..!');");
				 pw.println("</script>");
			}
			
			
		}
		catch(Exception e)
		{
			pw.print(e);
		}
	}

}
