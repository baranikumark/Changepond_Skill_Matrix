var isNew=true;

function addEmployee()
{
	 var form=$("formEmployee");
  if(form.valid())
	  {
	  	var url="";
	  	var data="";
	  	var method;
	  	
	  	if(isNew==true)
	  		{
	  		url='addEmployee.jsp';
	  		data=$("#formEmployee").serialize();
	  		method='POST'
	  		}
	  	$.ajax({
	  		type:method,
	  		url:url,
	  		dataType:'JSON',
	  		data:data,
	  		success:function(data)
	  		{
	  		
	  			if(isNew==true)
	  				{
	  				alert("Added");
	  				}
	  		}
	  			
	  	});
	  }
}