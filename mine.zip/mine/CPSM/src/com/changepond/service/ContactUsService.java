package com.changepond.service;

import com.changepond.model.ContactUs;

public interface ContactUsService {

	public int save(ContactUs conus);
}
