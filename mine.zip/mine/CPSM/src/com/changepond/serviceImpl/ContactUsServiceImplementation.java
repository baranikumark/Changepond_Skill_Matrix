package com.changepond.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.changepond.dao.DbConnection;
import com.changepond.model.ContactUs;
import com.changepond.service.ContactUsService;

public class ContactUsServiceImplementation implements ContactUsService {
	
	public int save(ContactUs conus)
	{
		int flag=0;
		String sql="insert into tbl_contactus values(?,?,?,?)";
		try
		{
			Connection con=DbConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, conus.getName());
			ps.setString(2, conus.getEmail());
			ps.setString(3, conus.getSubject());
			ps.setString(4, conus.getMessage());
			flag=ps.executeUpdate();
			con.close();
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return flag;
		
	}
	

}
