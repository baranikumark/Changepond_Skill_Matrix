﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeController.Models;
using System.Web.Security;



namespace AuthorizeController.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        Aravind_traineeEntities db = new Aravind_traineeEntities();
        // GET: /Account/
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(tbl_login user)
        {
            var count = db.tbl_login.Where(u => u.username == user.username && u.userpassword == user.userpassword).Count();

            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(user.username, false);
                return RedirectToAction("Index", "Employee");
            }
            else
            {
                TempData["message"] = "U r not Authorized to this page";

                return View();
            }
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
	}
}